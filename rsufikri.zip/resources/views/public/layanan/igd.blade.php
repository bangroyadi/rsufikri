@extends('layouts.app')

@section('title', 'Instalasi Gawat Darurat (IGD 24 Jam) | RSU Fikri Medika Karawang')
@section('meta_description', 'Layanan IGD 24 Jam RSU Fikri Medika Karawang siap siaga menangani kasus gawat darurat medis dengan tim dokter emergency, ambulans, dan trauma center.')

@section('schema_jsonld')
<script type="application/ld+json">
{!! json_encode(app(\App\Services\SeoService::class)->generateBreadcrumbSchema([
    'Beranda' => url('/'),
    'Layanan' => url('/layanan/rawat-inap'),
    'IGD 24 Jam' => url('/layanan/igd')
]), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}
</script>
@endsection

@section('content')
<h1 class="sr-only">Instalasi Gawat Darurat (IGD 24 Jam) RSU Fikri Medika Karawang</h1>

@php
    $galleryImages = isset($service) ? $service->gallery_images : [];
    $hasCustomGallery = isset($service) && is_array($service->gallery) && count($service->gallery) > 0;

    if ($hasCustomGallery && !empty($galleryImages) && count($galleryImages) > 0) {
        $displayGallery = array_map(function($url, $idx) {
            return [
                'img' => $url,
                'badge' => 'Fasilitas ' . ($idx + 1),
                'title' => 'Instalasi Gawat Darurat - Foto ' . ($idx + 1),
            ];
        }, $galleryImages, array_keys($galleryImages));
        $lightboxImages = $galleryImages;
    } else {
        $displayGallery = [
            ['img' => asset('banner-igd.png'), 'badge' => 'Layanan 24h', 'title' => 'Area Penanganan IGD'],
            ['img' => asset('trauma-center.png'), 'badge' => 'Trauma Center', 'title' => 'Unit Penanganan Kecelakaan'],
            ['img' => asset('gedung2_web.jpg'), 'badge' => 'Akses Masuk', 'title' => 'Gedung Utama IGD'],
            ['img' => asset('gedung1_web.jpg'), 'badge' => 'Evakuasi', 'title' => 'Armada Ambulans 24h'],
        ];
        $lightboxImages = array_column($displayGallery, 'img');
    }
@endphp

<!-- MAIN CONTENT SECTION (WIDE CONTAINER STANDAR APLIKASI WEB MODERN) -->
<section class="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10" x-data="igdPageGalleryApp({{ json_encode($lightboxImages) }})">



    <!-- TOP SECTION (TENTANG IGD) -->
    <div class="w-full">
        <div class="bg-white p-6 sm:p-8 rounded-3xl shadow-sm space-y-6 flex flex-col justify-between border border-gray-100">
            <div class="space-y-6">
                <div class="flex items-center gap-3.5 pb-5 border-b border-gray-100">
                    <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-[#0e7c47] flex items-center justify-center text-xl font-extrabold">
                        <i class="fa-solid fa-hospital-user"></i>
                    </div>
                    <div>
                        <span class="inline-block px-3 py-1 rounded-full bg-emerald-100 text-[#0e7c47] text-xs font-bold mb-1">
                            {{ __('Pelayanan Utama Emergency') }}
                        </span>
                        <h2 class="text-lg sm:text-xl font-bold text-gray-900">{{ __('Tentang Instalasi Gawat Darurat') }}</h2>
                    </div>
                </div>

                <div class="prose max-w-none text-gray-600 leading-relaxed text-xs sm:text-sm space-y-4 font-medium">
                    <p>
                        <strong>Instalasi Gawat Darurat (IGD 24 Jam) RSU Fikri Medika Karawang</strong> merupakan garda terdepan penanganan medis gawat darurat yang siap melayani pasien dengan respon cepat, tepat, dan mengedepankan prinsip keselamatan medis serta nilai-nilai kehangatan Islami.
                    </p>
                    <p>
                        Ditunjang oleh tim dokter siaga 24 jam, perawat medis bersertifikasi khusus gawat darurat (BTCLS/ATCLS), serta ruang penanganan medis terintegrasi yang terhubung langsung ke unit penunjang 24 jam.
                    </p>
                </div>
            </div>

            <div class="pt-4 border-t border-gray-100 flex items-center gap-2 text-xs font-bold text-[#0e7c47]">
                <i class="fa-solid fa-circle-check"></i>
                <span>Menerima Pasien BPJS Kesehatan & Asuransi Kasus Emergency 24h</span>
            </div>
        </div>
    </div>

    <!-- FULL-WIDTH SECTIONS BELOW (FULL CONTAINER SPAN FOR MAX SPACE & READABILITY) -->
    <div class="space-y-10 pt-2">

        <!-- FULL WIDE SECTION 1: FASILITAS & PENUNJANG IGD CARDS (4-COLS GRID) -->
        <div class="space-y-5">
            <div class="flex items-center gap-2">
                <span class="inline-block px-3 py-1 rounded-full bg-emerald-100 text-[#0e7c47] text-xs font-bold">Fasilitas Utama</span>
                <h3 class="text-xl font-extrabold text-gray-900">Fasilitas & Peralatan Medis IGD</h3>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                
                <div class="bg-white p-6 rounded-3xl shadow-sm space-y-3.5 hover:shadow-md transition-all border border-gray-100/50">
                    <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-[#0e7c47] flex items-center justify-center text-xl font-bold">
                        <i class="fa-solid fa-heart-pulse"></i>
                    </div>
                    <h4 class="font-bold text-gray-900 text-base">Ruang Resusitasi & Triage</h4>
                    <p class="text-xs text-gray-600 leading-relaxed font-medium">
                        Bedside Monitor, Defibrillator, Syringe Pump, dan peralatan resusitasi jantung paru modern.
                    </p>
                </div>

                <div class="bg-white p-6 rounded-3xl shadow-sm space-y-3.5 hover:shadow-md transition-all border border-gray-100/50">
                    <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-[#0e7c47] flex items-center justify-center text-xl font-bold">
                        <i class="fa-solid fa-truck-medical"></i>
                    </div>
                    <h4 class="font-bold text-gray-900 text-base">Ambulans Emergency 24 Jam</h4>
                    <p class="text-xs text-gray-600 leading-relaxed font-medium">
                        Armada ambulans gawat darurat dilengkapi tabung oksigen, stretcher medis, & tim penjemputan.
                    </p>
                </div>

                <div class="bg-white p-6 rounded-3xl shadow-sm space-y-3.5 hover:shadow-md transition-all border border-gray-100/50">
                    <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-[#0e7c47] flex items-center justify-center text-xl font-bold">
                        <i class="fa-solid fa-vial"></i>
                    </div>
                    <h4 class="font-bold text-gray-900 text-base">Laboratorium & Radiologi 24 Jam</h4>
                    <p class="text-xs text-gray-600 leading-relaxed font-medium">
                        Pemeriksaan darah cito 24h, Rontgen Digital, dan CT-Scan untuk respon diagnostik instan.
                    </p>
                </div>

                <div class="bg-white p-6 rounded-3xl shadow-sm space-y-3.5 hover:shadow-md transition-all border border-gray-100/50">
                    <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-[#0e7c47] flex items-center justify-center text-xl font-bold">
                        <i class="fa-solid fa-capsules"></i>
                    </div>
                    <h4 class="font-bold text-gray-900 text-base">Farmasi 24 Jam & Ruang OK</h4>
                    <p class="text-xs text-gray-600 leading-relaxed font-medium">
                        Pengadaan obat-obatan gawat darurat 24 jam serta akses langsung ke Kamar Operasi (OK) cito.
                    </p>
                </div>

            </div>
        </div>

        <!-- FULL WIDE SECTION 2: GALERI FASILITAS IGD (DYNAMIC PHOTO GRID) -->
        <div class="bg-white p-6 sm:p-8 rounded-3xl shadow-sm space-y-6">
            <div class="flex items-center justify-between gap-3 pb-4 border-b border-gray-100 flex-wrap">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-emerald-50 text-[#0e7c47] flex items-center justify-center text-lg font-bold">
                        <i class="fa-solid fa-images"></i>
                    </div>
                    <div>
                        <h3 class="font-extrabold text-gray-900 text-lg">Galeri Fasilitas & Sarana IGD</h3>
                        <p class="text-xs text-gray-500 font-medium">Visualisasi ruangan medis & sarana penanganan darurat RSU Fikri Medika</p>
                    </div>
                </div>
                @if(count($displayGallery) > 0)
                <div class="text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                    <span>{{ count($displayGallery) }} Foto</span>
                </div>
                @endif
            </div>

            <!-- PHOTO GRID -->
            @if(count($displayGallery) > 0)
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                @foreach($displayGallery as $idx => $gPhoto)
                <div @click="openLightbox({{ $idx }})"
                     class="relative rounded-2xl overflow-hidden shadow-xs group h-56 border border-gray-100 cursor-pointer transition-all duration-300 hover:shadow-md hover:-translate-y-1 bg-slate-900">
                    <img src="{{ $gPhoto['img'] }}" alt="{{ $gPhoto['title'] }}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
                    
                    <!-- ZOOM HOVER ICON -->
                    <div class="absolute inset-0 bg-slate-950/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <div class="w-9 h-9 rounded-full bg-white/95 text-slate-800 flex items-center justify-center shadow-md text-sm font-bold">
                            <i class="fa-solid fa-magnifying-glass-plus text-[#0e7c47]"></i>
                        </div>
                    </div>

                    <div class="absolute bottom-3 left-3 right-3 text-white">
                        <span class="text-[10px] font-extrabold px-2 py-0.5 rounded bg-[#0e7c47] uppercase tracking-wider mb-1 inline-block">{{ $gPhoto['badge'] }}</span>
                        <h4 class="text-xs font-bold truncate">{{ $gPhoto['title'] }}</h4>
                    </div>
                </div>
                @endforeach
            </div>
            @else
            <div class="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                <p class="text-xs text-slate-500 font-medium">Foto galeri belum tersedia untuk layanan ini.</p>
            </div>
            @endif
        </div>

        <!-- FULL WIDE SECTION 3: TRIAGE SYSTEM EDUCATIONAL CARD -->
        <div class="bg-white p-6 sm:p-8 rounded-3xl shadow-sm space-y-6">
            <div class="flex items-center gap-3 pb-4 border-b border-gray-100">
                <div class="w-10 h-10 rounded-xl bg-emerald-50 text-[#0e7c47] flex items-center justify-center text-lg font-bold">
                    <i class="fa-solid fa-layer-group"></i>
                </div>
                <div>
                    <h3 class="font-extrabold text-gray-900 text-lg">Alur Sistem Triage Medis IGD</h3>
                    <p class="text-xs text-gray-500 font-medium">Prioritas penanganan medis berdasarkan tingkat kegawatan pasien</p>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
                <!-- KATEGORI MERAH -->
                <div class="p-5 rounded-2xl bg-red-50 space-y-2 border border-red-100">
                    <div class="flex items-center gap-2">
                        <span class="w-3.5 h-3.5 rounded-full bg-red-600 animate-pulse"></span>
                        <h4 class="font-extrabold text-red-900 text-sm">Prioritas 1 (Merah)</h4>
                    </div>
                    <p class="text-xs text-red-800 leading-relaxed font-medium">
                        <strong>Kondisi Kritis / Resusitasi:</strong> Penanganan instan tanpa penundaan (Gagal napas, henti jantung, pendarahan berat).
                    </p>
                </div>

                <!-- KATEGORI KUNING -->
                <div class="p-5 rounded-2xl bg-amber-50 space-y-2 border border-amber-100">
                    <div class="flex items-center gap-2">
                        <span class="w-3.5 h-3.5 rounded-full bg-amber-500"></span>
                        <h4 class="font-extrabold text-amber-900 text-sm">Prioritas 2 (Kuning)</h4>
                    </div>
                    <p class="text-xs text-amber-800 leading-relaxed font-medium">
                        <strong>Kondisi Gawat Tidak Darurat:</strong> Penanganan cepat (Nyeri hebat, patah tulang, sesak derajat sedang).
                    </p>
                </div>

                <!-- KATEGORI HIJAU -->
                <div class="p-5 rounded-2xl bg-emerald-50 space-y-2 border border-emerald-100">
                    <div class="flex items-center gap-2">
                        <span class="w-3.5 h-3.5 rounded-full bg-emerald-600"></span>
                        <h4 class="font-extrabold text-emerald-900 text-sm">Prioritas 3 (Hijau)</h4>
                    </div>
                    <p class="text-xs text-emerald-800 leading-relaxed font-medium">
                        <strong>Kondisi Non-Urgent:</strong> Penanganan medis umum (Luka ringan, demam sedang, diare tanpa dehidrasi).
                    </p>
                </div>
            </div>
        </div>

        <!-- FULL WIDE SECTION 4: KAPAN HARUS SEGERA KE IGD? (INTERACTIVE ACCORDION CARDS NO BORDER) -->
        <div class="bg-white p-6 sm:p-8 rounded-3xl shadow-sm space-y-6" x-data="{ activeEmergencyCard: null }">
            <div class="flex items-center gap-3 pb-4 border-b border-gray-100">
                <div class="w-10 h-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center text-lg font-bold">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                </div>
                <div>
                    <h3 class="font-extrabold text-gray-900 text-lg">Kapan Harus Segera ke IGD?</h3>
                    <p class="text-xs text-gray-500 font-medium">Klik kartu kondisi darurat medis di bawah untuk melihat tanda bahaya & pertolongan pertama</p>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                
                <!-- 1. KECELAKAAN & CEDERA -->
                <div class="bg-slate-50/80 hover:bg-slate-100/90 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden space-y-2"
                     @click="activeEmergencyCard = (activeEmergencyCard === 1 ? null : 1)">
                    <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center text-base font-bold shrink-0">
                                <i class="fa-solid fa-car-burst"></i>
                            </div>
                            <div>
                                <h4 class="font-extrabold text-gray-900 text-xs leading-tight">Kecelakaan & Cedera</h4>
                                <span class="text-[10px] font-bold text-rose-600 px-2 py-0.5 bg-rose-50 rounded-full inline-block mt-0.5">Darurat</span>
                            </div>
                        </div>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform duration-300 text-slate-400"
                           :class="activeEmergencyCard === 1 ? 'rotate-180 text-rose-600' : ''"></i>
                    </div>

                    <div x-show="activeEmergencyCard === 1" x-transition class="pt-2 border-t border-slate-200/60 text-[11px] text-gray-600 leading-relaxed font-medium">
                        Benturan kepala keras, patah tulang terbuka/deformitas, muntah menyembur, atau trauma berat akibat kecelakaan lalu lintas.
                    </div>
                </div>

                <!-- 2. STROKE MEDIS -->
                <div class="bg-slate-50/80 hover:bg-slate-100/90 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden space-y-2"
                     @click="activeEmergencyCard = (activeEmergencyCard === 2 ? null : 2)">
                    <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-base font-bold shrink-0">
                                <i class="fa-solid fa-brain"></i>
                            </div>
                            <div>
                                <h4 class="font-extrabold text-gray-900 text-xs leading-tight">Stroke Medis</h4>
                                <span class="text-[10px] font-bold text-red-600 px-2 py-0.5 bg-red-50 rounded-full inline-block mt-0.5">Kritis</span>
                            </div>
                        </div>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform duration-300 text-slate-400"
                           :class="activeEmergencyCard === 2 ? 'rotate-180 text-red-600' : ''"></i>
                    </div>

                    <div x-show="activeEmergencyCard === 2" x-transition class="pt-2 border-t border-slate-200/60 text-[11px] text-gray-600 leading-relaxed font-medium">
                        Senyum miring mendadak (wajah pelo), kelemahan anggota gerak satu sisi tubuh, atau kehilangan kemampuan berbicara mendadak.
                    </div>
                </div>

                <!-- 3. SERANGAN JANTUNG -->
                <div class="bg-slate-50/80 hover:bg-slate-100/90 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden space-y-2"
                     @click="activeEmergencyCard = (activeEmergencyCard === 3 ? null : 3)">
                    <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-base font-bold shrink-0">
                                <i class="fa-solid fa-heart-pulse"></i>
                            </div>
                            <div>
                                <h4 class="font-extrabold text-gray-900 text-xs leading-tight">Serangan Jantung</h4>
                                <span class="text-[10px] font-bold text-red-600 px-2 py-0.5 bg-red-50 rounded-full inline-block mt-0.5">Kritis</span>
                            </div>
                        </div>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform duration-300 text-slate-400"
                           :class="activeEmergencyCard === 3 ? 'rotate-180 text-red-600' : ''"></i>
                    </div>

                    <div x-show="activeEmergencyCard === 3" x-transition class="pt-2 border-t border-slate-200/60 text-[11px] text-gray-600 leading-relaxed font-medium">
                        Nyeri dada tertindih beban berat >15 menit menjalar ke lengan/leher/rahang, disertai keringat dingin hebat & mual.
                    </div>
                </div>

                <!-- 4. SESAK NAPAS BERAT -->
                <div class="bg-slate-50/80 hover:bg-slate-100/90 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden space-y-2"
                     @click="activeEmergencyCard = (activeEmergencyCard === 4 ? null : 4)">
                    <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center text-base font-bold shrink-0">
                                <i class="fa-solid fa-lungs"></i>
                            </div>
                            <div>
                                <h4 class="font-extrabold text-gray-900 text-xs leading-tight">Sesak Napas Berat</h4>
                                <span class="text-[10px] font-bold text-amber-600 px-2 py-0.5 bg-amber-50 rounded-full inline-block mt-0.5">Darurat</span>
                            </div>
                        </div>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform duration-300 text-slate-400"
                           :class="activeEmergencyCard === 4 ? 'rotate-180 text-amber-600' : ''"></i>
                    </div>

                    <div x-show="activeEmergencyCard === 4" x-transition class="pt-2 border-t border-slate-200/60 text-[11px] text-gray-600 leading-relaxed font-medium">
                        Kesulitan bernapas parah, laju napas sangat cepat, bibir/kuku mulai kebiruan, atau tidak bisa mengucapkan satu kalimat utuh.
                    </div>
                </div>

                <!-- 5. PERDARAHAN HEBAT -->
                <div class="bg-slate-50/80 hover:bg-slate-100/90 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden space-y-2"
                     @click="activeEmergencyCard = (activeEmergencyCard === 5 ? null : 5)">
                    <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center text-base font-bold shrink-0">
                                <i class="fa-solid fa-droplet"></i>
                            </div>
                            <div>
                                <h4 class="font-extrabold text-gray-900 text-xs leading-tight">Perdarahan Hebat</h4>
                                <span class="text-[10px] font-bold text-rose-600 px-2 py-0.5 bg-rose-50 rounded-full inline-block mt-0.5">Darurat</span>
                            </div>
                        </div>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform duration-300 text-slate-400"
                           :class="activeEmergencyCard === 5 ? 'rotate-180 text-rose-600' : ''"></i>
                    </div>

                    <div x-show="activeEmergencyCard === 5" x-transition class="pt-2 border-t border-slate-200/60 text-[11px] text-gray-600 leading-relaxed font-medium">
                        Darah memancar deras atau tidak kunjung berhenti pasca-penekanan 10 menit, muntah darah, atau perdarahan aktif pemicu pusing berat.
                    </div>
                </div>

                <!-- 6. KEJANG & PINGSAN -->
                <div class="bg-slate-50/80 hover:bg-slate-100/90 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden space-y-2"
                     @click="activeEmergencyCard = (activeEmergencyCard === 6 ? null : 6)">
                    <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-base font-bold shrink-0">
                                <i class="fa-solid fa-user-slash"></i>
                            </div>
                            <div>
                                <h4 class="font-extrabold text-gray-900 text-xs leading-tight">Kejang & Pingsan</h4>
                                <span class="text-[10px] font-bold text-red-600 px-2 py-0.5 bg-red-50 rounded-full inline-block mt-0.5">Kritis</span>
                            </div>
                        </div>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform duration-300 text-slate-400"
                           :class="activeEmergencyCard === 6 ? 'rotate-180 text-red-600' : ''"></i>
                    </div>

                    <div x-show="activeEmergencyCard === 6" x-transition class="pt-2 border-t border-slate-200/60 text-[11px] text-gray-600 leading-relaxed font-medium">
                        Pingsan lama tanpa respons panggilan, kejang berulang >5 menit, tidak sadarkan diri, atau kebingungan berat pasca-trauma.
                    </div>
                </div>

                <!-- 7. KERACUNAN MEDIS -->
                <div class="bg-slate-50/80 hover:bg-slate-100/90 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden space-y-2"
                     @click="activeEmergencyCard = (activeEmergencyCard === 7 ? null : 7)">
                    <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center text-base font-bold shrink-0">
                                <i class="fa-solid fa-vial-virus"></i>
                            </div>
                            <div>
                                <h4 class="font-extrabold text-gray-900 text-xs leading-tight">Keracunan Medis</h4>
                                <span class="text-[10px] font-bold text-amber-600 px-2 py-0.5 bg-amber-50 rounded-full inline-block mt-0.5">Darurat</span>
                            </div>
                        </div>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform duration-300 text-slate-400"
                           :class="activeEmergencyCard === 7 ? 'rotate-180 text-amber-600' : ''"></i>
                    </div>

                    <div x-show="activeEmergencyCard === 7" x-transition class="pt-2 border-t border-slate-200/60 text-[11px] text-gray-600 leading-relaxed font-medium">
                        Tertelan bahan kimia berbahaya, racun serangga/obat berlebih, muntah berulang hebat, atau penurunan kesadaran akibat racun.
                    </div>
                </div>

                <!-- 8. LUKA BAKAR LUAS -->
                <div class="bg-slate-50/80 hover:bg-slate-100/90 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer overflow-hidden space-y-2"
                     @click="activeEmergencyCard = (activeEmergencyCard === 8 ? null : 8)">
                    <div class="flex items-center justify-between gap-2">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center text-base font-bold shrink-0">
                                <i class="fa-solid fa-fire-flame-curved"></i>
                            </div>
                            <div>
                                <h4 class="font-extrabold text-gray-900 text-xs leading-tight">Luka Bakar Luas</h4>
                                <span class="text-[10px] font-bold text-rose-600 px-2 py-0.5 bg-rose-50 rounded-full inline-block mt-0.5">Darurat</span>
                            </div>
                        </div>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform duration-300 text-slate-400"
                           :class="activeEmergencyCard === 8 ? 'rotate-180 text-rose-600' : ''"></i>
                    </div>

                    <div x-show="activeEmergencyCard === 8" x-transition class="pt-2 border-t border-slate-200/60 text-[11px] text-gray-600 leading-relaxed font-medium">
                        Luka bakar akibat api/bahan kimia luas, mengenai area wajah/jalan napas, atau sengatan listrik tegangan tinggi.
                    </div>
                </div>

            </div>
        </div>

        <!-- FULL WIDE SECTION 5: FAQ ACCORDION -->
        <div class="bg-white p-6 sm:p-8 rounded-3xl shadow-sm space-y-6" x-data="{ activeFaq: null }">
            <div class="flex items-center gap-3 pb-4 border-b border-gray-100">
                <div class="w-10 h-10 rounded-xl bg-emerald-50 text-[#0e7c47] flex items-center justify-center text-lg font-bold">
                    <i class="fa-solid fa-circle-question"></i>
                </div>
                <div>
                    <h3 class="font-extrabold text-gray-900 text-lg">Pertanyaan Umum (FAQ) IGD</h3>
                    <p class="text-xs text-gray-500 font-medium">Informasi seputar pelayanan emergency, BPJS Kesehatan, & ambulans</p>
                </div>
            </div>

            <div class="space-y-3">
                <!-- FAQ 1 -->
                <div class="rounded-2xl bg-gray-50/70 overflow-hidden">
                    <button @click="activeFaq = (activeFaq === 1 ? null : 1)" class="w-full p-4.5 text-left font-bold text-gray-900 text-xs sm:text-sm flex items-center justify-between gap-4 hover:text-[#0e7c47] transition-colors">
                        <span>Apakah IGD RSU Fikri Medika melayani pasien BPJS Kesehatan?</span>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform text-gray-400" :class="activeFaq === 1 ? 'rotate-180 text-[#0e7c47]' : ''"></i>
                    </button>
                    <div x-show="activeFaq === 1" x-transition class="p-4.5 pt-0 text-xs text-gray-600 leading-relaxed font-medium">
                        Ya, untuk kondisi gawat darurat (emergency), pasien BPJS Kesehatan dapat langsung berobat ke IGD RSU Fikri Medika Karawang tanpa memerlukan Surat Rujukan dari Faskes 1 (Puskesmas/Klinik).
                    </div>
                </div>

                <!-- FAQ 2 -->
                <div class="rounded-2xl bg-gray-50/70 overflow-hidden">
                    <button @click="activeFaq = (activeFaq === 2 ? null : 2)" class="w-full p-4.5 text-left font-bold text-gray-900 text-xs sm:text-sm flex items-center justify-between gap-4 hover:text-[#0e7c47] transition-colors">
                        <span>Dokumen apa saja yang perlu dibawa saat ke IGD?</span>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform text-gray-400" :class="activeFaq === 2 ? 'rotate-180 text-[#0e7c47]' : ''"></i>
                    </button>
                    <div x-show="activeFaq === 2" x-transition class="p-4.5 pt-0 text-xs text-gray-600 leading-relaxed font-medium">
                        Prioritas utama IGD adalah pertolongan medis pasien. Namun jika memungkinkan, siapkan KTP/Kartu Keluarga dan Kartu BPJS/Asuransi kesehatan pasien.
                    </div>
                </div>

                <!-- FAQ 3 -->
                <div class="rounded-2xl bg-gray-50/70 overflow-hidden">
                    <button @click="activeFaq = (activeFaq === 3 ? null : 3)" class="w-full p-4.5 text-left font-bold text-gray-900 text-xs sm:text-sm flex items-center justify-between gap-4 hover:text-[#0e7c47] transition-colors">
                        <span>Bagaimana cara memesan Ambulans IGD RSU Fikri Medika?</span>
                        <i class="fa-solid fa-chevron-down text-xs transition-transform text-gray-400" :class="activeFaq === 3 ? 'rotate-180 text-[#0e7c47]' : ''"></i>
                    </button>
                    <div x-show="activeFaq === 3" x-transition class="p-4.5 pt-0 text-xs text-gray-600 leading-relaxed font-medium">
                        Anda dapat langsung menghubungi hotline IGD di (0267) 861-5555 atau melalui WhatsApp Ambulans 24 Jam di nomor 0812-3456-7890.
                    </div>
                </div>
            </div>
        </div>

    </div>

    {{-- LIGHTBOX MODAL --}}
    <div x-show="lightboxOpen"
         x-cloak
         @keydown.escape.window="closeLightbox()"
         class="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-sm"
         style="display: none;">
        <button @click="closeLightbox()"
                class="absolute top-4 right-4 text-white text-3xl hover:text-gray-300 z-50 p-2 cursor-pointer transition">
            <i class="fa-solid fa-xmark"></i>
        </button>
        <button @click="prevImage()"
                class="absolute left-4 top-1/2 -translate-y-1/2 text-white text-2xl hover:text-gray-300 z-50 p-3 bg-white/10 hover:bg-white/20 rounded-full cursor-pointer transition">
            <i class="fa-solid fa-chevron-left"></i>
        </button>
        <button @click="nextImage()"
                class="absolute right-4 top-1/2 -translate-y-1/2 text-white text-2xl hover:text-gray-300 z-50 p-3 bg-white/10 hover:bg-white/20 rounded-full cursor-pointer transition">
            <i class="fa-solid fa-chevron-right"></i>
        </button>
        <div class="relative max-w-5xl max-h-[85vh] flex flex-col items-center justify-center">
            <img :src="images[activeImageIndex]"
                 alt="Instalasi Gawat Darurat"
                 class="max-w-full max-h-[80vh] object-contain rounded-xl shadow-2xl">
            <div class="text-white text-center text-xs mt-3 bg-slate-900/80 px-4 py-1.5 rounded-full border border-white/10">
                <span x-text="activeImageIndex + 1"></span> / <span x-text="images.length"></span>
            </div>
        </div>
    </div>

</section>

<script>
function igdPageGalleryApp(initialImages) {
    return {
        images: initialImages || [],
        lightboxOpen: false,
        activeImageIndex: 0,
        openLightbox(index) {
            this.activeImageIndex = index;
            this.lightboxOpen = true;
            document.body.style.overflow = 'hidden';
        },
        closeLightbox() {
            this.lightboxOpen = false;
            document.body.style.overflow = 'auto';
        },
        nextImage() {
            if (this.images.length > 0) {
                this.activeImageIndex = (this.activeImageIndex + 1) % this.images.length;
            }
        },
        prevImage() {
            if (this.images.length > 0) {
                this.activeImageIndex = (this.activeImageIndex - 1 + this.images.length) % this.images.length;
            }
        }
    }
}
</script>

@endsection
