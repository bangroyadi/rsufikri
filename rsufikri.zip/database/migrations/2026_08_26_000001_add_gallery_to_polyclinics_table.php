<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('polyclinics', function (Blueprint $table) {
            if (!Schema::hasColumn('polyclinics', 'gallery')) {
                $table->json('gallery')->nullable()->after('image');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('polyclinics', function (Blueprint $table) {
            if (Schema::hasColumn('polyclinics', 'gallery')) {
                $table->dropColumn('gallery');
            }
        });
    }
};
